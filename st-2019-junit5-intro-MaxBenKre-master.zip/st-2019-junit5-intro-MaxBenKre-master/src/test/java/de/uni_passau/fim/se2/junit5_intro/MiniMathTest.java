package de.uni_passau.fim.se2.junit5_intro;

class MiniMathTest {

}